@echo off
REM Builds GStatus_Leaderboard.exe, GStatus_Member.exe and GStatus_Ceremony.exe  (run on Windows, Python 3.10+ installed)
cd /d "%~dp0.."
python -m venv .venv-exe || goto :err
call .venv-exe\Scripts\activate.bat
python -m pip install -r exe\requirements-exe.txt || goto :err

set DATA=--add-data "templates;templates" --add-data "static;static" --add-data "config.json;." --paths exe --paths .
set HIDDEN=--hidden-import app --hidden-import supabase_store

pyinstaller --noconfirm --clean --onefile --windowed --name GStatus_Leaderboard %DATA% %HIDDEN% exe\GStatus_Leaderboard.py || goto :err
pyinstaller --noconfirm --clean --onefile --windowed --name GStatus_Member      %DATA% %HIDDEN% exe\GStatus_Member.py || goto :err
pyinstaller --noconfirm --clean --onefile --windowed --name GStatus_Ceremony    %DATA% %HIDDEN% exe\GStatus_Ceremony.py || goto :err

echo.
echo Done. Your files are in the "dist" folder:
echo    dist\GStatus_Leaderboard.exe
echo    dist\GStatus_Member.exe
echo    dist\GStatus_Ceremony.exe
pause
exit /b 0
:err
echo.
echo Build failed - see the messages above.
pause
exit /b 1

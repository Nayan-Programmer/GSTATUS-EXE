"""Shared launcher: runs the G-Status Flask app locally and shows it in a desktop window.

Three flavours (see GStatus_Leaderboard.py / GStatus_Member.py / GStatus_Ceremony.py):
  * "leaderboard" - leaderboard pages + any student's profile (opened by clicking a name)
  * "member"      - Member ID lookup + that student's status page
  * "ceremony"    - a picker for Rank Ceremony / Weekly Ceremony, plus the ceremony screens

Every flavour asks for a password first.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import shutil
import socket
import sys
import threading
import time

# SHA-256 of the access password (the plain text is not stored in the exe).
PASSWORD_SHA256 = "7dcc259dd7deb2fa6c7bb0952a4eb4060ba921077fff0c668ad54521695c6279"


def password_ok(candidate: str) -> bool:
    digest = hashlib.sha256((candidate or "").strip().encode("utf-8")).hexdigest()
    return hmac.compare_digest(digest, PASSWORD_SHA256)


def base_dir() -> str:
    """Folder that holds the .exe (or this script when run from source). Writable."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def bundle_dir() -> str:
    """Folder with the bundled app files (PyInstaller unpack dir, or the project root)."""
    if getattr(sys, "frozen", False):
        return getattr(sys, "_MEIPASS", base_dir())
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load_env_file(path: str) -> None:
    """Optional gstatus.env next to the exe: KEY=VALUE lines (e.g. SUPABASE_URL, SUPABASE_KEY)."""
    if not os.path.isfile(path):
        return
    with open(path, "r", encoding="utf-8-sig") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


LOGIN_HTML = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<style>
  body{{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
       background:#0f172a;font-family:Segoe UI,Arial,sans-serif;color:#e2e8f0}}
  form{{background:#1e293b;padding:32px 28px;border-radius:16px;width:min(340px,86vw);
       box-shadow:0 10px 40px rgba(0,0,0,.4);text-align:center}}
  h1{{font-size:20px;margin:0 0 4px}} p{{margin:0 0 18px;color:#94a3b8;font-size:14px}}
  input{{width:100%;box-sizing:border-box;padding:12px;border-radius:10px;border:1px solid #334155;
        background:#0f172a;color:#fff;font-size:16px}}
  button{{margin-top:14px;width:100%;padding:12px;border:0;border-radius:10px;background:#f59e0b;
         color:#111;font-weight:700;font-size:16px;cursor:pointer}}
  .err{{color:#f87171;margin:10px 0 0;font-size:14px}}
</style></head><body>
<form method="post" action="/__login">
  <h1>{title}</h1><p>Enter password to continue</p>
  <input type="password" name="password" placeholder="Password" autofocus required>
  <button type="submit">Unlock</button>{error}
</form></body></html>"""

CEREMONY_HOME = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>G-Status Ceremony</title>
<style>
  body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
       background:radial-gradient(circle at top,#1e293b,#0b1020);font-family:Segoe UI,Arial,sans-serif;color:#fff}
  .box{text-align:center;padding:24px}
  h1{margin:0 0 6px;font-size:28px} p{margin:0 0 28px;color:#94a3b8}
  .row{display:flex;gap:20px;flex-wrap:wrap;justify-content:center}
  a{display:block;min-width:230px;padding:28px 22px;border-radius:18px;text-decoration:none;
    background:#1e293b;color:#fff;font-size:20px;font-weight:700;border:2px solid #f59e0b;
    transition:transform .15s,background .15s}
  a:hover{transform:translateY(-3px);background:#273449}
  small{display:block;margin-top:6px;color:#94a3b8;font-weight:400;font-size:13px}
</style></head><body><div class="box">
  <h1>G-Status Ceremony</h1><p>Select which ceremony to run</p>
  <div class="row">
    <a href="/rank">&#127916; Rank Ceremony<small>Overall top 3</small></a>
    <a href="/rank/weekly">&#127916; Weekly Ceremony<small>This week's top 3</small></a>
  </div></div></body></html>"""

# Per-flavour tidy-up CSS (hides links to pages that are not part of that exe).
HIDE_LEADERBOARD = """
<style id="gs-exe">
  .live-cluster a.btn-ghost, .lb-tabs a[target="_blank"], a[href^="/rank"], a[href^="/admin"] { display: none !important; }
</style>"""

HIDE_MEMBER = """
<style id="gs-exe">
  a[href^="/leaderboard"], a[href^="/rank"], a[href^="/admin"], a[href^="/students/admin"] { display: none !important; }
</style>"""

HIDE_CEREMONY = """
<style id="gs-exe">
  a[href$="/admin"], a.round[title="Rank setup"] { display: none !important; }
  #gs-back { position: fixed; top: 10px; left: 10px; z-index: 99999; padding: 8px 14px; border-radius: 999px;
             background: rgba(15,23,42,.75); color: #fff; font: 600 14px Segoe UI, Arial, sans-serif;
             text-decoration: none; border: 1px solid rgba(255,255,255,.25); }
  #gs-back:hover { background: rgba(245,158,11,.9); color: #111; }
</style>"""
BACK_LINK = '<a id="gs-back" href="/">&larr; Select ceremony</a>'


def build_app(mode: str, title: str):
    root = bundle_dir()
    sys.path.insert(0, root)
    load_env_file(os.path.join(base_dir(), "gstatus.env"))

    # config.json lives next to the exe so the sheet links can be edited without rebuilding.
    cfg_path = os.path.join(base_dir(), "config.json")
    if not os.path.isfile(cfg_path):
        bundled = os.path.join(root, "config.json")
        if os.path.isfile(bundled):
            shutil.copyfile(bundled, cfg_path)

    import app as gs  # the existing Flask app, unchanged
    from flask import Response, redirect, request, session

    gs.CONFIG_PATH = cfg_path
    flask_app = gs.app
    flask_app.secret_key = os.urandom(32)  # new every launch -> the password is asked each time
    flask_app.config.update(SESSION_COOKIE_SAMESITE="Lax", SESSION_COOKIE_HTTPONLY=True)

    blocked_single = {"leaderboard", "admin", "rank", "healthz", "__hmr_gate", "robots.txt", "__login"}

    def is_member_path(path: str) -> bool:
        parts = [p for p in path.strip("/").split("/") if p]
        return len(parts) == 1 and parts[0].lower() not in blocked_single and "." not in parts[0]

    def allowed(path: str) -> bool:
        if path.startswith(("/static/", "/students/photo/")) or path == "/favicon.ico":
            return True
        if mode == "leaderboard":
            # leaderboard + every student's profile (click a name in the table)
            return path == "/leaderboard" or path.startswith("/api/student/") or is_member_path(path)
        if mode == "member":
            return path == "/" or path.startswith("/api/student/") or is_member_path(path)
        # ceremony
        return path in ("/", "/rank", "/rank/weekly", "/api/rank", "/api/rank/weekly") or path.startswith(
            ("/rank/photo/", "/rank/weekly/photo/")
        )

    def login_page(error: bool = False, status: int = 200):
        err = '<div class="err">Wrong password, try again.</div>' if error else ""
        return Response(LOGIN_HTML.format(title=title, error=err), status=status, mimetype="text/html")

    @flask_app.before_request
    def _gate():
        path = request.path
        if path == "/__login":
            if request.method == "POST":
                if password_ok(request.form.get("password", "")):
                    session["ok"] = True
                    return redirect("/")
                return login_page(error=True, status=401)
            return login_page()
        if not session.get("ok"):
            if path.startswith("/api/"):
                return Response("Locked", status=401)
            return login_page()
        if mode == "leaderboard" and path == "/":
            return redirect("/leaderboard")
        if mode == "ceremony" and path == "/":
            return Response(CEREMONY_HOME, mimetype="text/html")
        if not allowed(path):
            return Response("This page is not available in this app.", status=404)
        return None

    @flask_app.after_request
    def _tidy(resp):
        if resp.mimetype == "text/html" and not resp.direct_passthrough and session.get("ok"):
            css = {"leaderboard": HIDE_LEADERBOARD, "member": HIDE_MEMBER}.get(mode, HIDE_CEREMONY)
            body = resp.get_data(as_text=True)
            if "</head>" in body:
                body = body.replace("</head>", css + "</head>", 1)
            if mode == "ceremony" and request.path != "/" and "</body>" in body:
                body = body.replace("</body>", BACK_LINK + "</body>", 1)
            resp.set_data(body)
        return resp

    return flask_app


def run(mode: str, title: str, start_path: str = "/") -> None:
    flask_app = build_app(mode, title)
    from werkzeug.serving import make_server

    port = free_port()
    server = make_server("127.0.0.1", port, flask_app, threaded=True)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    url = f"http://127.0.0.1:{port}{start_path}"

    try:
        import webview  # pywebview: native window (uses Edge WebView2 on Windows)

        webview.create_window(title, url, width=1100, height=800, min_size=(420, 600))
        webview.start()
    except Exception:
        # No pywebview / WebView2: fall back to the default browser and keep serving.
        import webbrowser

        webbrowser.open(url)
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            pass
    finally:
        server.shutdown()

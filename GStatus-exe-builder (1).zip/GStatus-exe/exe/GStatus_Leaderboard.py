from launcher_common import run

if __name__ == "__main__":
    run("leaderboard", "G-Status Leaderboard", "/")

from launcher_common import run

if __name__ == "__main__":
    run("ceremony", "G-Status Ceremony", "/")

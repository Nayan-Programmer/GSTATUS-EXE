from launcher_common import run

if __name__ == "__main__":
    run("member", "G-Status Member Lookup", "/")

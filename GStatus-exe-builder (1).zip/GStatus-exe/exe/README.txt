G-STATUS DESKTOP APPS
=====================
Three small Windows apps made from the same G-Status project.
Each one asks for a PASSWORD when it opens.

  GStatus_Leaderboard.exe -> leaderboard (Rankings / Hostel / Day School / GStar / Weekly).
                             Click any student's name to open that student's profile.
  GStatus_Member.exe      -> type a Member ID and see that student's profile.
  GStatus_Ceremony.exe    -> pick "Rank Ceremony" or "Weekly Ceremony" and run it.
                             (top-left "Select ceremony" button goes back to the picker)

Nothing else (admin / setup pages) is reachable from these apps.

BUILD (once, on a Windows PC with Python 3.10+ from python.org, "Add to PATH" ticked)
  1. Unzip this folder.
  2. Double-click  exe\build.bat
  3. Take the three .exe files from the new "dist" folder.

USE
  * Needs internet (it reads your Google Sheet, same as the website).
  * On first run each exe creates config.json next to itself - this holds the Google Sheet + Student Master links. Edit it with Notepad to change the sheet; no rebuild needed.
  * Student photos and ceremony photos need Supabase. Put these two lines in a file called gstatus.env next to the exe:
        SUPABASE_URL=...
        SUPABASE_KEY=...
    Without it the apps still work; photos just don't show.
  * Windows 10/11 already has Edge WebView2, which the window uses. If it is missing, the app opens your normal browser instead.
  * Windows SmartScreen may warn about an unsigned exe: More info -> Run anyway.

CHANGE THE PASSWORD
  Open exe\launcher_common.py and replace PASSWORD_SHA256 with the SHA-256 of the new password
  (python -c "import hashlib;print(hashlib.sha256(b'NEWPASSWORD').hexdigest())"), then run build.bat again.
